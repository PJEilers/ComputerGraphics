#ifndef VERTEX_H
#define VERTEX_H



struct vertex {
    float x;
    float y;
    float z;
    float r;
    float g;
    float b;
};



#endif // VERTEX_H

